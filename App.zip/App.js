import  React, {useState, useEffect} from 'react';
import { Button, View, ScrollView, Text, StyleSheet, Image, TouchableHighlight, TouchableOpacity, TextInput, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {Picker} from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
// Sookha. J. SELF

function HomeScreen({ navigation }) {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [numPages, setNumPages] = useState();
  const [genre, setGenre] = useState('');
  const [totalPages, setTotalPages] = useState(0);
  const [averagePages, setAveragePages] = useState(0);
  const [lastThreeBooks, setLastThreeBooks] = useState([]);
  
  useEffect(() => {
    loadLastThreeBooks();
  }, []);
  // Sookha. J. SELF

  const loadLastThreeBooks = async () => {
    try {
      const serializedData = await AsyncStorage.getItem('books');
      if (serializedData) {
        const allBooks = JSON.parse(serializedData);
        const reversedBooks = allBooks.slice().reverse();
        const lastThree = reversedBooks.slice(0, 1); 
        setLastThreeBooks(lastThree);

        const totalPageNumbers = allBooks.reduce((sum, book) => sum + parseInt(book.numPages, 10), 0);
        const averagePageNumber = totalPageNumbers / allBooks.length;

        setTotalPages(totalPageNumbers);
        setAveragePages(averagePageNumber);
      }
    } catch (error) {
      console.error('Error loading last three books:', error);
    }
  };

  const renderBook = (book, index) => (
    <View key={index} style={styles.savedBooksContainer}>
      
      <Text style={styles.info}>
        Title: {book.title}{'  '}
        Author: {book.author}{'  '}
        Genre: {book.genre}{'  '}
        <Text>{`Page Number: ${book.pageNumber}`}</Text>
      </Text>
    </View>
  );
  // Sookha. J. SELF

  const renderPlaceholder = () => (
    <View style={[styles.box, styles.placeholder]}>
      <Text style={styles.placeholderText}>No books available</Text>
    </View>
  );

  const renderStatistics = () => {
    if (lastThreeBooks.length > 0) {
      return (
        <View style={styles.statisticsContainer}>
          <View style={styles.statisticsBox}>
            <Text>Total Pages</Text>
            <Text>{totalPages}</Text>
          </View>
          <View style={styles.statisticsBox}>
            <Text>Average Pages</Text>
            <Text>{averagePages.toFixed(2)}</Text>
          </View>
        </View>
      );
    }
    return null;
  };
  // Sookha. J. SELF
  
  return (
<View style={styles.container}>
      <Text style={styles.mainHeading}>Bookworm</Text>
      <Text style={styles.subHeading}>Add New Books</Text>
      
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>

    <View style={styles.savedBooksContainer}>
      <Text style={styles.savedBooksLabel}>Saved Books</Text>
      {lastThreeBooks.length > 0 ? renderBook(lastThreeBooks[0], 0) : renderPlaceholder()}
      {renderStatistics()}
    </View>
      
      <TouchableOpacity
        style={styles.touchableOpacity}
        title="Enter Book"
        onPress={() => navigation.navigate('EnterBook')}
      >
        <Text style={{color: "white"}}>ENTER BOOK</Text>
        </TouchableOpacity>
    </View>
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      
      <Button
        style={styles.menuButton}
        title="History"
        onPress={() => navigation.navigate('History')}
      />

      <Button 
        title="Genre"
        onPress={() => navigation.navigate('Genre')}
        style={styles.menuButton}
     />    
    </View>
    </View>
  );
}
// Sookha. J. SELF

function EnterBookScreen({ navigation }) {

  const genreList = [
    {id: '1' ,name: 'Action and adventure', category: 'Fiction', count: 0},
    {id: '2' ,name: 'Alternate history', category: 'Fiction', count: 0},
    {id: '3' ,name: 'Anthology', category: 'Fiction', count: 0},
    {id: '4' ,name: 'Chick lit', category: 'Fiction', count: 0},
    {id: '5' ,name: 'Children', category: 'Fiction', count: 0},
    {id: '6' ,name: 'Classic', category: 'Fiction', count: 0},
    {id: '7' ,name: 'Comic book', category: 'Fiction', count: 0},
    {id: '8' ,name: 'Coming-of-age', category: 'Fiction', count: 0},
    {id: '9' ,name: 'Crime', category: 'Fiction', count: 0},
    {id: '10' ,name: 'Drama', category: 'Fiction', count: 0},
    {id: '11' ,name: 'Fairytale', category: 'Fiction', count: 0},
    {id: '12' ,name: 'Fantasy', category: 'Fiction', count: 0},
    {id: '13' ,name: 'Graphic novel', category: 'Fiction', count: 0},
    {id: '14' ,name: 'Historical fiction', category: 'Fiction', count: 0},
    {id: '15' ,name: 'Horror', category: 'Fiction', count: 0},
    {id: '16' ,name: 'Mystery', category: 'Fiction', count: 0},
    {id: '17' ,name: 'Paranormal romance', category: 'Fiction', count: 0},
    {id: '18' ,name: 'Picture book', category: 'Fiction', count: 0},
    {id: '19' ,name: 'Poetry', category: 'Fiction', count: 0},
    {id: '20' ,name: 'Political thriller', category: 'Fiction', count: 0},
    {id: '21' ,name: 'Romance', category: 'Fiction', count: 0},
    {id: '22' ,name: 'Satire', category: 'Fiction', count: 0},
    {id: '23' ,name: 'Science fiction', category: 'Fiction', count: 0},
    {id: '24' ,name: 'Short story', category: 'Fiction', count: 0},
    {id: '25' ,name: 'Suspense', category: 'Fiction', count: 0},
    {id: '26' ,name: 'Thriller', category: 'Fiction', count: 0},
    {id: '27' ,name: 'Western', category: 'Fiction', count: 0},
    {id: '28' ,name: 'Young adult', category: 'Fiction', count: 0},
    {id: '29' ,name: 'Art/architecture', category: 'Non-fiction', count: 0},
    {id: '30' ,name: 'Autobiography', category: 'Non-fiction', count: 0},
    {id: '31' ,name: 'Biography', category: 'Non-fiction', count: 0},
    {id: '32' ,name: 'Business/economics', category: 'Non-fiction', count: 0},
    {id: '33' ,name: 'Crafts/hobbies', category: 'Non-fiction', count: 0},
    {id: '34' ,name: 'Cookbook', category: 'Non-fiction', count: 0},
    {id: '35' ,name: 'Diary', category: 'Non-fiction', count: 0},
    {id: '36' ,name: 'Dictionary', category: 'Non-fiction', count: 0},
    {id: '37' ,name: 'Encyclopedia', category: 'Non-fiction', count: 0},
    {id: '38' ,name: 'Guide', category: 'Non-fiction', count: 0},
    {id: '39' ,name: 'Health/fitness', category: 'Non-fiction', count: 0},
    {id: '40' ,name: 'History', category: 'Non-fiction', count: 0},
    {id: '41' ,name: 'Home and garden', category: 'Non-fiction', count: 0},
    {id: '42' ,name: 'Humor', category: 'Non-fiction', count: 0},
    {id: '43' ,name: 'Journal', category: 'Non-fiction', count: 0},
    {id: '44' ,name: 'Math', category: 'Non-fiction', count: 0},
    {id: '45' ,name: 'Memoir', category: 'Non-fiction', count: 0},
    {id: '46' ,name: 'Philosophy', category: 'Non-fiction', count: 0},
    {id: '47' ,name: 'Prayer', category: 'Non-fiction', count: 0},
    {id: '48' ,name: 'Religion, spirituality, and new age', category: 'Non-fiction', count: 0},
    {id: '49' ,name: 'Textbook', category: 'Non-fiction', count: 0},
    {id: '50' ,name: 'True crime', category: 'Non-fiction', count: 0},
    {id: '51' ,name: 'Review', category: 'Non-fiction', count: 0},
    {id: '52' ,name: 'Science', category: 'Non-fiction', count: 0},
    {id: '53' ,name: 'Self help', category: 'Non-fiction', count: 0},
    {id: '54' ,name: 'Sports and leisure', category: 'Non-fiction', count: 0},
    {id: '55' ,name: 'Travel', category: 'Non-fiction', count: 0},
    {id: '56' ,name: 'True crime', category: 'Non-fiction', count: 0}
   ];
  
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [numPages, setNumPages] = useState(0);
  const [genre, setGenre] = useState('');
  const [books, setBooks] = useState([]);

  useEffect(() => {
    async function loadSavedBooks() {
      try {
        const serializedData = await AsyncStorage.getItem('books');
        if (serializedData) {
          const savedBooks = JSON.parse(serializedData);
          setBooks(savedBooks);
        }
      } catch (error) {
        console.error('Error loading saved books:', error);
      }
    }

    loadSavedBooks();
  }, []);

  const handleSave = async () => {
    if (title && author && numPages && genre) {
      try {
        const bookData = {
          title: title,
          author: author,
          numPages: Number(numPages), 
          genre: genre,
        };

        const newBooks = [...books, bookData];
        setBooks(newBooks);
        const serializedData = JSON.stringify(newBooks);
        await AsyncStorage.setItem('books', serializedData);

        setTitle('');
        setAuthor('');
        setNumPages(0);
        setGenre('');

        Alert.alert('Book Saved');
      } catch (error) {
        console.error('Error saving book:', error);
      }
    } else {
      Alert.alert('Please fill in all fields.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.mainHeading}>Bookworm</Text>
      <Text style={styles.subHeading}>ADD NEW BOOK</Text>
      <View style={styles.bookInfo}>
        
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Book Title:</Text>
        <TextInput
          style={styles.input}
          value={title}
          onChangeText={(text) => setTitle(text)}
          placeholder="Title"
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Author:</Text>
        <TextInput
          style={styles.input}
          value={author}
          onChangeText={(text) => setAuthor(text)}
          placeholder="Author(s)"
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Page Number:</Text>
        <TextInput
          style={styles.input}
          value={numPages}
          onChangeText={(text) => setNumPages(text)}
          placeholder="Page Number"
          keyboardType="numeric"
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Genre:</Text>
        <Picker
          selectedValue={genre}
          onValueChange={(itemValue, itemIndex) => setGenre(itemValue)}
        >
          {genreList.map((genre) => (
            <Picker.Item key={genre.id} label={genre.name} value={genre.name} />
          ))}
        </Picker>
      </View>

      <Button title="Save" onPress={handleSave} />
      
      <View style={styles.savedBooksContainer}>
  <Text style={styles.savedBooksLabel}>Saved Books:</Text>
  <ScrollView style={{ height: 200 }}>
    {books.map((book, index) => (
      <View key={index} style={styles.savedBook}>
        <Text>{`Title: ${book.title}`}</Text>
        <Text>{`Author: ${book.author}`}</Text>
        <Text>{`Page Number: ${book.numPages}`}</Text>
        <Text>{`Genre: ${book.genre}`}</Text>
      </View>
    ))}
  </ScrollView>
</View>

    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      
      <Button
        title="GENRES"
        onPress={() => navigation.navigate('Genre')}
      />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
    </View>
    </View>
    
  );
}
// Sookha. J. SELF

function HistoryScreen({ navigation }) {

  const [lastThreeBooks, setLastThreeBooks] = useState([]);

  useEffect(() => {
    loadLastThreeBooks();
  }, []);

  const loadLastThreeBooks = async () => {
    try {
      const serializedData = await AsyncStorage.getItem('books');
      if (serializedData) {
        const allBooks = JSON.parse(serializedData);
        const reversedBooks = allBooks.slice().reverse();
        const lastThree = reversedBooks.slice(0, 3);
        setLastThreeBooks(lastThree);
      }
    } catch (error) {
      console.error('Error loading last three books:', error);
    }
  };

  const renderBook = (book, index) => (
    <View key={index} style={styles.bookContainer}>
      <View style={styles.box}>
        
        <Text style={styles.info}>
          Title: {book.title}{'\n'}
          Author: {book.author}{'\n'}
          Genre: {book.genre}{'\n'}
          <Text>{`Page Number: ${book.numPages}`}</Text>
        </Text>
      </View>
      <TouchableOpacity onPress={() => handleDeleteBook(index)} style={styles.deleteButton}>
        <Text style={{color: "white"}}>Delete</Text>
      </TouchableOpacity>
    </View>
  );

  const handleDeleteBook = async (index) => {
    try {
      const updatedBooks = lastThreeBooks.filter((_, i) => i !== index);
      setLastThreeBooks(updatedBooks);

      // Update AsyncStorage
      const serializedData = JSON.stringify(updatedBooks);
      await AsyncStorage.setItem('books', serializedData);

      Alert.alert('Book Deleted', 'The selected book has been deleted.');
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };
  // Sookha. J. SELF

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      {lastThreeBooks.length > 0 ? (
        lastThreeBooks.map((book, index) => renderBook(book, index))
      ) : (
        <Text style={styles.placeholderText}>No books saved yet...</Text>
      )}
     <Button 
     title="History"
     onPress={() => navigation.navigate('History')}
     style={styles.menuButton}
     /> 
        <Button title="Go back" onPress={() => navigation.goBack() } />
    </View>
  );
}

function GenreScreen({ navigation, selectedGenres, setSelectedGenres }) {

  const [savedGenres, setSavedGenres] = useState([]);
  const genreList = [
    {id: '1' ,name: 'Action and adventure', category: 'Fiction', count: 0},
    {id: '2' ,name: 'Alternate history', category: 'Fiction', count: 0},
    {id: '3' ,name: 'Anthology', category: 'Fiction', count: 0},
    {id: '4' ,name: 'Chick lit', category: 'Fiction', count: 0},
    {id: '5' ,name: 'Children', category: 'Fiction', count: 0},
    {id: '6' ,name: 'Classic', category: 'Fiction', count: 0},
    {id: '7' ,name: 'Comic book', category: 'Fiction', count: 0},
    {id: '8' ,name: 'Coming-of-age', category: 'Fiction', count: 0},
    {id: '9' ,name: 'Crime', category: 'Fiction', count: 0},
    {id: '10' ,name: 'Drama', category: 'Fiction', count: 0},
    {id: '11' ,name: 'Fairytale', category: 'Fiction', count: 0},
    {id: '12' ,name: 'Fantasy', category: 'Fiction', count: 0},
    {id: '13' ,name: 'Graphic novel', category: 'Fiction', count: 0},
    {id: '14' ,name: 'Historical fiction', category: 'Fiction', count: 0},
    {id: '15' ,name: 'Horror', category: 'Fiction', count: 0},
    {id: '16' ,name: 'Mystery', category: 'Fiction', count: 0},
    {id: '17' ,name: 'Paranormal romance', category: 'Fiction', count: 0},
    {id: '18' ,name: 'Picture book', category: 'Fiction', count: 0},
    {id: '19' ,name: 'Poetry', category: 'Fiction', count: 0},
    {id: '20' ,name: 'Political thriller', category: 'Fiction', count: 0},
    {id: '21' ,name: 'Romance', category: 'Fiction', count: 0},
    {id: '22' ,name: 'Satire', category: 'Fiction', count: 0},
    {id: '23' ,name: 'Science fiction', category: 'Fiction', count: 0},
    {id: '24' ,name: 'Short story', category: 'Fiction', count: 0},
    {id: '25' ,name: 'Suspense', category: 'Fiction', count: 0},
    {id: '26' ,name: 'Thriller', category: 'Fiction', count: 0},
    {id: '27' ,name: 'Western', category: 'Fiction', count: 0},
    {id: '28' ,name: 'Young adult', category: 'Fiction', count: 0},
    {id: '29' ,name: 'Art/architecture', category: 'Non-fiction', count: 0},
    {id: '30' ,name: 'Autobiography', category: 'Non-fiction', count: 0},
    {id: '31' ,name: 'Biography', category: 'Non-fiction', count: 0},
    {id: '32' ,name: 'Business/economics', category: 'Non-fiction', count: 0},
    {id: '33' ,name: 'Crafts/hobbies', category: 'Non-fiction', count: 0},
    {id: '34' ,name: 'Cookbook', category: 'Non-fiction', count: 0},
    {id: '35' ,name: 'Diary', category: 'Non-fiction', count: 0},
    {id: '36' ,name: 'Dictionary', category: 'Non-fiction', count: 0},
    {id: '37' ,name: 'Encyclopedia', category: 'Non-fiction', count: 0},
    {id: '38' ,name: 'Guide', category: 'Non-fiction', count: 0},
    {id: '39' ,name: 'Health/fitness', category: 'Non-fiction', count: 0},
    {id: '40' ,name: 'History', category: 'Non-fiction', count: 0},
    {id: '41' ,name: 'Home and garden', category: 'Non-fiction', count: 0},
    {id: '42' ,name: 'Humor', category: 'Non-fiction', count: 0},
    {id: '43' ,name: 'Journal', category: 'Non-fiction', count: 0},
    {id: '44' ,name: 'Math', category: 'Non-fiction', count: 0},
    {id: '45' ,name: 'Memoir', category: 'Non-fiction', count: 0},
    {id: '46' ,name: 'Philosophy', category: 'Non-fiction', count: 0},
    {id: '47' ,name: 'Prayer', category: 'Non-fiction', count: 0},
    {id: '48' ,name: 'Religion, spirituality, and new age', category: 'Non-fiction', count: 0},
    {id: '49' ,name: 'Textbook', category: 'Non-fiction', count: 0},
    {id: '50' ,name: 'True crime', category: 'Non-fiction', count: 0},
    {id: '51' ,name: 'Review', category: 'Non-fiction', count: 0},
    {id: '52' ,name: 'Science', category: 'Non-fiction', count: 0},
    {id: '53' ,name: 'Self help', category: 'Non-fiction', count: 0},
    {id: '54' ,name: 'Sports and leisure', category: 'Non-fiction', count: 0},
    {id: '55' ,name: 'Travel', category: 'Non-fiction', count: 0},
    {id: '56' ,name: 'True crime', category: 'Non-fiction', count: 0}
   ];
  const [selectedLanguage, setSelectedLanguage] = useState();
	const [genre, setGenre] = useState();

  const CustomPicker = ({ options, selectedValue, onValueChange }) => {
    const [modalVisible, setModalVisible] = useState(false);
  
    const handleSelect = (value) => {
      setModalVisible(false);
      onValueChange(value);
    };
  
  useEffect(() => {
    setSavedGenres(selectedGenres);
  }, [selectedGenres]);

  return (

    <View style={styles.container}>
      <TouchableOpacity onPress={() => setModalVisible(true)} style={styles.selectedValue}>
        <Text>{selectedValue}</Text>
      </TouchableOpacity>

      <Modal
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
        <Picker
          selectedValue={genre}
          onValueChange={(itemValue, itemIndex) => setGenre(itemValue)}
        >
          {genreList.map((genre) => (
            <Picker.Item key={genre.id} label={genre.name} value={genre.name} />
          ))}
        </Picker>
          <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
            <View style={styles.overlay} />
          </TouchableWithoutFeedback>

          <FlatList
            data={options}
            renderItem={renderItem}
            keyExtractor={(item) => item.value.toString()}
          />
        </View>
      </Modal>

    <View style={styles.container}>
      <CustomPicker
        options={genreList.map(genre => ({ label: genre.name, value: genre.name }))}
        selectedValue={genre}
        onValueChange={(value) => setGenre(value)}
      />
      <Text style={styles.dispText}>
        Selected genre: {genre}
      </Text>
      <Text style={styles.dispText}>Pick Genre</Text> 

      // Sookha. J. SELF
      
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    </View>
    </View>
    </View>
  );
}
};

// Sookha. J. SELF

const Stack = createNativeStackNavigator();

function MyStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="History" component={HistoryScreen} />
      <Stack.Screen name="EnterBook" component={EnterBookScreen} />
      <Stack.Screen name="Genre" component={GenreScreen} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
    
  },
  savedBooksContainer: {
    marginTop: 20,
  },
  label: {
    
    fontSize: 16,
    marginBottom: 5,
  },
  savedBooksLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  horizontalLineAbove: {
    height: 5,
    backgroundColor: 'black',
    position: 'absolute',
    top: 20,
    width: '100%',
  },

  savedBook: {
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    paddingBottom: 10,
  },

  inputContainer: {
    marginBottom: 28,
    flex: 1,
    padding: 15,
    height: 44,
    alignSelf: "stretch",
    borderRadius: 6,
    paddingHorizontal: 16,
    fontWeight: "300",
  },

  input: {
    
    borderWidth: 1,
    borderColor: "#575DD9",
    alignSelf: "stretch",
    // marginTop: 4,
    padding: 8,
    height: 44,
    borderRadius: 6,
    paddingHorizontal: 16,
    fontSize: 24,
    fontWeight: "300",
    
  },
  savedBooksContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
    paddingTop: 15,
  },
  mainHeading: {
    fontSize: 47,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subHeading: {
    fontSize: 28,
    marginBottom: 20,
  },
  bookInfo: {
    marginBottom: 20,
  },
  bookImage: {
    width: 300,
    height: 400,
    marginRight: 15,
    flex: 1,
  },
  dispText: {
		margin: 24,
		fontSize: 32,
		textAlign: 'center',
	},

  touchableOpacity: {
    
    alignItems: 'center', 
    justifyContent: 'center',
    backgroundColor: '#75E07F',
    borderRadius: 6,
    paddingVertical: 12,
    paddingHorizontal: 32,
    alignself: "stretch",
    marginHorizontal: 32,
    marginTop: 32,
  },
  bookDetails: {
    fontSize: 28,
    flex: 1,
  },
  blocks: {
    marginTop: 20,
    marginBottom: 30,
  },
  addButton: {
    backgroundColor: '#75E07F',
    padding: 10,
    borderRadius: 50,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 62,
  },
  deleteButton: {
    backgroundColor: '#DB4444',
    padding: 10,
    borderRadius: 50,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 62,
  },
  menu: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  menuButton: {
    backgroundColor: '#B29BFA',
    padding: 10,
    borderRadius: 5,
    flex: 1,
    alignItems: 'center',
    marginLeft: 5,
    marginRight: 5,
  },
});

// Sookha. J. SELF

export default function App() {
  return (
    <NavigationContainer>
      <MyStack />
    </NavigationContainer>
  );
}

// Reference List:
// Sookha. J. 
// SELF
// 2023